/*PER VERIFICARE L'UNIVOCITA' DELLA PRIMARY KEY POSSIAMO 
FARE BENISSIMO UN CONTEGGIO DI TUTTE LE COLONNE 
DOPO UN RAGGRUPPAMENTO DELLE PK E COM HAVING COUNT(*)>1 VERIFICHIAMO
SE LA PK SI RIPETE ALMENO UNA VOLTA E IL RISULTATO LO METTIAMO IN 
UNA COLONNA A PARTE.SE NON ABBIAMO RISULTATI SIGNIFICA CHE NON CI SONO DUPLICATI DI PK*/

SELECT CategoryID, COUNT(*)AS Duplicati
FROM Category
GROUP BY CategoryID
HAVING COUNT(*) > 1;

SELECT RegionID, COUNT(*)AS Duplicati
FROM Region
GROUP BY RegionID
HAVING COUNT(*) > 1;

SELECT ProductID, COUNT(*) AS Duplicati
FROM Product
GROUP BY ProductID
HAVING COUNT(*) > 1;

SELECT StateID, COUNT(*)AS Duplicati
FROM State
GROUP BY StateID
HAVING COUNT(*) > 1;

SELECT SalesID, COUNT(*) AS Duplicati
FROM Sales
GROUP BY SalesID
HAVING COUNT(*) >1;

/*2)	Esporre l’elenco delle transazioni indicando nel result set il codice documento, la data, 
il nome del prodotto, la categoria del prodotto, il nome dello stato, 
il nome della regione di vendita e un campo booleano valorizzato in base 
alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)*/

SELECT 
    S.SalesID AS DocID,
    S.SalesDate AS SalesDate,
    P.ProductName AS ProductDescription,
    C.CategoryName AS ProductCategory,
    ST.StateName AS StateName,
    R.RegionName AS SalesRegion,
 CASE 
    WHEN DATEDIFF(CURRENT_DATE, S.SalesDate) > 180 THEN TRUE
    ELSE FALSE
END AS 180DAYS
FROM 
    Sales AS S
INNER JOIN 
    Product AS P ON S.FK_ProductID = P.ProductID
INNER JOIN 
    Category AS C ON P.FK_CategoryID = C.CategoryID
INNER JOIN 
    Region AS R ON S.FK_RegionID = R.RegionID
LEFT JOIN 
    State AS ST ON ST.FK_RegionID = R.RegionID  ;
    /*LA LEFT JOIN PERCHE' CI POSSONO ESSERE CASI CHE
    LO STATO NON E' ASSOCIATO ALLA REGIONE QUESTO
    MI PERMETTE DI NON PERDERE LE VENDITE*/
    
    /*3)Esporre l’elenco dei prodotti che hanno venduto, in totale, 
    una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito. 
    (ogni valore della condizione deve risultare da una query e non deve essere inserito a mano). 
    Nel result set devono comparire solo il codice prodotto e il totale venduto.*/
    
SELECT 
    S.FK_ProductID AS ProductID,
    SUM(S.Quantity) AS TotalSales
FROM 
    Sales AS S
WHERE 
    YEAR(S.SalesDate) = (SELECT MAX(YEAR(SalesDate)) FROM Sales)
GROUP BY 
    S.FK_ProductID
HAVING 
    SUM(S.Quantity) > (
        SELECT AVG(Quantity)
        FROM Sales
        WHERE YEAR(SalesDate) = (SELECT MAX(YEAR(SalesDate)) FROM Sales)
    );

/*4)Esporre l’elenco dei soli prodotti venduti e per ognuno
     di questi il fatturato totale per anno. */
     
	SELECT
    S.FK_ProductID AS ProductID,
    P.ProductName,
    YEAR(S.SalesDate) AS Anno,
    SUM(S.Amount) AS Fatturatototale
FROM
    Sales AS S
    INNER JOIN
    Product AS P ON S.FK_ProductID = P.ProductID
GROUP BY
    S.FK_ProductID,
    YEAR(S.SalesDate);
    
/*5)Esporre il fatturato totale per stato per anno. Ordina il 
risultato per data e per fatturato decrescente.*/
SELECT
    ST.StateName,
    DATE(S.SalesDate) AS Data_,
    YEAR (S.SalesDate) AS Anno,
    SUM(S.Amount) AS FatturatoTotale
FROM
    Sales AS S
INNER JOIN
    Region AS R ON S.FK_RegionID = R.RegionID
INNER JOIN
    State AS ST ON ST.FK_RegionID = R.RegionID
GROUP BY
    ST.StateName,
    DATE(S.SalesDate),
	YEAR (S.SalesDate)
ORDER BY
    FatturatoTotale DESC;
    
/*6)	Rispondere alla seguente domanda: 
qual è la categoria di articoli maggiormente richiesta dal mercato?*/

SELECT
    C.CategoryName,
    SUM(S.Quantity) AS TotalAmountSales
FROM
    Sales AS S
INNER JOIN
    Product AS P ON S.FK_ProductID = P.ProductID
INNER JOIN
    Category AS C ON P.FK_CategoryID = C.CategoryID
GROUP BY
    C.CategoryName
    /* da qui in poi andiamo a prendere solo il prodotto piu' venduto tramite subquery
    che va a prendere il calcolo di ogni prodotto venduto per categoria della query sopra e andiamo a estrarre il
    valore MAX e con having filtriamo solo la categoria piu' venduta
*/
HAVING
    SUM(S.Quantity) = (
        SELECT MAX(TotalQuantity)
        FROM (
            SELECT SUM(S.Quantity) AS TotalQuantity
            FROM Sales AS S
            INNER JOIN Product AS P ON S.FK_ProductID = P.ProductID
            INNER JOIN Category AS C ON P.FK_CategoryID = C.CategoryID
            GROUP BY C.CategoryName
        ) AS subquery
    );
    
    /*7)quali sono i prodotti invenduti? Proponi due approcci risolutivi differenti.*/
    -- PRIMO APPROCCIO-- 
    SELECT 
    P.ProductID,
    P.ProductName
FROM 
    Product AS P
LEFT JOIN 
    Sales AS S ON P.ProductID = S.FK_ProductID
WHERE 
    S.SalesID IS NULL;
    
    -- SECONDO APPROCCIO --
    SELECT 
    P.ProductID,
    P.ProductName
FROM 
    Product AS P
WHERE 
    P.ProductID NOT IN (
        SELECT DISTINCT FK_ProductID 
        /*ELENCO PRODOTTI CHE SONO VENDUTI MA CON 
        LA CLAUSOLA NOT IN GLI DICIAMO LETTERALMENTO
        IL PRODOTTO NON E' NELL'ELENCO? ALLORA SIGNIFICA CHE E' INVENDUTO.SE LA CONDIZIONE E' VERA QUINDI PRODOTTO INVENDUTO 
        CI VIENE MOSTRATO IL PRODOTTO ALTRIMENTI NULL*/
        FROM Sales
    );
    
    /*8)	Creare una vista sui prodotti in modo tale da esporre una “versione denormalizzata” 
    delle informazioni utili (codice prodotto, nome prodotto, nome categoria)
    */
    
    CREATE VIEW Vista_Product_Denormalizzata AS
SELECT
    P.ProductID,
    P.ProductName,
    C.CategoryName
FROM
    Product AS P
INNER JOIN
    Category AS C ON P.FK_CategoryID = C.CategoryID;
    
    SELECT * FROM Vista_Product_Denormalizzata;
    
-- 9)Creare una vista per le informazioni geografiche --
CREATE VIEW View_State_Region AS
SELECT
    ST.StateID,
    ST.StateName,
    R.RegionID,
    R.RegionName
FROM
    State AS ST
INNER JOIN
    Region AS R ON ST.FK_RegionID = R.RegionID;
    
    SELECT* From View_State_Region