CREATE DATABASE PROVA_SQL;
USE PROVA_SQL;

/*INIZIAMO ANDANDO A CREARE LE TABELLE  DOPO AVER ESAMINATO
  LA TRACCIA E INDIVIDUATO LE ENTITA' E ATTRIBUTI E LE ENTITA' RELAZIONALI PER 
  DEFINIRE LE PRIMARY KEY E FOREIGN KEY*/
  
  
CREATE TABLE Category (
    CategoryID INT ,
    CategoryName VARCHAR(100),
    CONSTRAINT PK_Category PRIMARY KEY(CategoryID)
);
CREATE TABLE Region (
    RegionID INT,
    RegionName VARCHAR(100),
    CONSTRAINT PK_Region PRIMARY KEY (RegionID)
);
CREATE TABLE Product (
    ProductID INT,
    ProductName VARCHAR(100),
    FK_CategoryID INT,
    FK_RegionID int,
    CONSTRAINT PK_Product PRIMARY KEY (ProductID),
    CONSTRAINT FK_Product_Category FOREIGN KEY (FK_CategoryID) REFERENCES Category(CategoryID),
    CONSTRAINT FK_Region FOREIGN KEY(FK_RegionID) REFERENCES Region(RegionID)
);
CREATE TABLE State (
    StateID INT ,
    StateName VARCHAR(100),
    FK_RegionID INT ,
    CONSTRAINT PK_Country PRIMARY KEY(StateID),
    CONSTRAINT FK_State FOREIGN KEY(FK_RegionID)REFERENCES Region(RegionID)
);
CREATE TABLE Sales(
    SalesID INT,
    SalesDate DATE ,
    Quantity INT,
    UnitPrice DECIMAL(10,2),
    Amount DECIMAL(10,2),
    FK_ProductID INT,
    FK_RegionID INT,
    CONSTRAINT PK_Sales PRIMARY KEY (SalesID),
    CONSTRAINT FK_Sales_Product FOREIGN KEY (FK_ProductID) REFERENCES Product(ProductID),
    CONSTRAINT FK_Sales_Region FOREIGN KEY (FK_RegionID) REFERENCES Region(RegionID)
);
/*ORA ANDIAMO A POPOLARE LE TABELLE*/

INSERT INTO Category(CategoryID, CategoryName) VALUES
(1, 'Bikes'),
(2, 'Clothing'),
(3, 'Accessories'),
(4, 'Electronics'),
(5, 'Toys'),
(6, 'Outdoor'),
(7, 'Fitness'),
(8, 'HomeGoods'),
(9, 'OfficeSupplies'),
(10, 'Books'),
(11, 'Gaming'),
(12, 'Music');

INSERT INTO Region (RegionID, RegionName)

VALUES
(1, 'WestEurope'),
(2, 'SouthEurope'),
(3, 'NorthAmerica'),
(4, 'SouthAmerica'),
(5, 'EastAsia'),
(6, 'MiddleEast'),
(7, 'Oceania'),
(8, 'NorthAfrica'),
(9, 'EastEurope'),
(10, 'CentralAmerica'),
(11, 'NorthAsia'),
(12, 'SouthAfrica');

INSERT INTO Product (ProductID, ProductName, FK_CategoryID,FK_RegionID) 
VALUES
(1, 'Bikes-100', 1,1),
(2, 'Bikes-200', 1,2),
(3, 'Bike Gloves M',2,3),
(4, 'Bike Gloves L', 2,4),
(5, 'Helmet', 3,5),
(6, 'Smartwatch',4,6),
(7, 'Action Figure', 5,7),
(8, 'Tent', 6,8),
(9, 'Yoga Mat', 7,9),
(10, 'Heaven Official Blessing', 10,10),
(11,'Joypad',11,11),
(12,'Vinyl',12,12),
(13, 'Printer', 8,4),
(14, 'Printer Paper',8,2);


INSERT INTO State(StateID, StateName, FK_RegionID) 
VALUES
(1, 'France', 1),
(2, 'Germany', 1),
(3, 'Italy', 2),
(4, 'Spain', 2),
(5, 'USA', 3),
(6, 'Canada', 3),
(7, 'Brazil', 4),
(8, 'Argentina', 4),
(9, 'Japan', 5),
(10, 'South Korea', 5),
(11, 'Russia', 9),
(12, 'South Africa', 12),
(13,'Greece',2),
(14, 'Australia', 7),       
(15, 'Morocco', 8),         
(16, 'Ukraine', 9),         
(17, 'Mexico', 10),         
(18, 'Kazakhstan', 11),   
(19, 'Saudi Arabia', 6);

INSERT INTO Sales (SalesID, SalesDate, Quantity, UnitPrice, Amount, FK_ProductID, FK_RegionID) VALUES
(1, '2024-04-01', 5, 300, 1500, 1, 1),
(2, '2024-05-15', 3, 450, 1350, 2, 1),
(3, '2024-06-20', 10, 50, 500, 3, 2),
(4, '2024-07-25', 7, 55, 385, 4, 2),
(5, '2025-01-10', 4, 200, 800, 5, 3),
(6, '2025-02-05', 2, 299, 598, 6, 3),
(7, '2024-09-01', 8, 80, 640, 7, 4),
(8, '2025-03-10', 5, 150, 750, 8, 4),
(9, '2025-03-20', 9, 30, 270, 9, 5),
(10, '2025-04-01', 2, 20, 40, 10, 5),
(11, '2024-08-01', 3, 120, 360, 11, 9),
(12, '2025-03-25', 4, 50, 200, 12, 12),
(13, '2025-01-20', 5, 400, 2000, 13, 8),
(14, '2025-02-10', 7, 15, 105, 14, 8),
(15, '2025-01-05', 6, 250, 1500, 1, 7),
(16, '2024-03-15', 4, 350, 1400, 2, 8),
(17, '2024-11-10', 5, 90, 450, 3, 9),
(18, '2025-01-30', 2, 600, 1200, 4, 10),
(19, '2025-03-01', 3, 500, 1500, 5, 11),
(20, '2025-03-15', 3, 120, 360, 6, 6);

